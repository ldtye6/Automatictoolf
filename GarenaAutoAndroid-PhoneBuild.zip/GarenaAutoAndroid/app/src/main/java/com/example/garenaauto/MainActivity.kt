package com.example.garenaauto

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var userInput: EditText
    private lateinit var passInput: EditText
    private lateinit var emailInput: EditText
    private lateinit var status: TextView
    private lateinit var timerText: TextView
    private var startedAt = 0L
    private var elapsed = 0L
    private val prefs by lazy { getSharedPreferences("local_accounts", MODE_PRIVATE) }
    private val alphabet = "abcdefghjkmnpqrstuvwxyz23456789"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 24, 39)
        window.navigationBarColor = Color.rgb(16, 24, 39)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(15, 23, 42)) }
        val title = TextView(this).apply {
            text = "Garena Auto Android"; textSize = 20f; setTextColor(Color.WHITE)
            setPadding(16, 16, 16, 10)
        }
        root.addView(title)
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 4, 12, 8) }
        userInput = input("Tên tài khoản")
        passInput = input("Mật khẩu")
        emailInput = input("Email của bạn")
        panel.addView(userInput); panel.addView(passInput); panel.addView(emailInput)

        val row1 = LinearLayout(this)
        row1.addView(button("Tạo thông tin") { generate() }, weight())
        row1.addView(button("Sao chép") { copyCredentials() }, weight())
        panel.addView(row1)
        val row2 = LinearLayout(this)
        row2.addView(button("Mở trang Garena") { web.loadUrl("https://sso.garena.com/") }, weight())
        row2.addView(button("Lưu sau khi đăng ký") { saveAccount() }, weight())
        panel.addView(row2)
        val row3 = LinearLayout(this)
        row3.addView(button("Xuất TXT") { exportAccounts() }, weight())
        row3.addView(button("Xóa danh sách") { clearAccounts() }, weight())
        panel.addView(row3)
        timerText = TextView(this).apply { text = "Thời gian: 00:00"; setTextColor(Color.WHITE); textSize = 14f; setPadding(4, 8, 4, 2) }
        panel.addView(timerText)
        val timerRow = LinearLayout(this)
        timerRow.addView(button("Bắt đầu / Tạm dừng") { toggleTimer() }, weight())
        timerRow.addView(button("Đặt lại") { elapsed = 0; startedAt = 0; updateTimer() }, weight())
        panel.addView(timerRow)
        status = TextView(this).apply { text = "Sẵn sàng. Bạn tự hoàn tất đăng ký và xác minh trên Garena."; setTextColor(Color.rgb(147,197,253)); textSize = 12f; setPadding(4, 8, 4, 8) }
        panel.addView(status)
        root.addView(panel)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            loadUrl("https://sso.garena.com/")
        }
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun input(hintText: String) = EditText(this).apply {
        hint = hintText; textSize = 14f; setSingleLine(true)
        setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        setPadding(12, 8, 12, 8)
        backgroundTintList = android.content.res.ColorStateList.valueOf(Color.GRAY)
    }
    private fun weight() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 11f; isAllCaps = false
        setOnClickListener { action() }
    }
    private fun randomText(n: Int) = (1..n).map { alphabet[Random.nextInt(alphabet.length)] }.joinToString("")
    private fun generate() {
        userInput.setText("user${randomText(8)}")
        passInput.setText("Aa!${randomText(13)}")
        status.text = "Đã tạo thông tin ngẫu nhiên. Hãy kiểm tra và tự nhập vào biểu mẫu."
    }
    private fun copyCredentials() {
        val text = "Tên: ${userInput.text}\nMật khẩu: ${passInput.text}\nEmail: ${emailInput.text}"
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Thông tin đăng ký", text))
        status.text = "Đã sao chép thông tin vào clipboard."
    }
    private fun saveAccount() {
        val u = userInput.text.toString().trim(); val p = passInput.text.toString(); val e = emailInput.text.toString().trim()
        if (u.isEmpty() || p.isEmpty() || e.isEmpty()) { status.text = "Nhập đủ tên, mật khẩu và email trước khi lưu."; return }
        val list = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        val obj = JSONObject().put("username", u).put("password", p).put("email", e)
            .put("savedAt", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))
        list.put(obj); prefs.edit().putString("items", list.toString()).apply()
        status.text = "Đã lưu trên thiết bị. Chỉ lưu sau khi Garena báo đăng ký thành công."
    }
    private fun exportAccounts() {
        val list = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        if (list.length() == 0) { status.text = "Chưa có tài khoản được lưu."; return }
        val body = (0 until list.length()).joinToString("\n\n") { i ->
            val a = list.getJSONObject(i)
            "#${i+1}\nTên: ${a.optString("username")}\nMật khẩu: ${a.optString("password")}\nEmail: ${a.optString("email")}\nNgày lưu: ${a.optString("savedAt")}"
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/plain"; putExtra(Intent.EXTRA_TITLE, "garena-accounts.txt")
        }
        pendingExport = body
        startActivityForResult(intent, 71)
    }
    private var pendingExport: String? = null
    @Deprecated("Deprecated in Android API, retained for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 71 && resultCode == Activity.RESULT_OK && data?.data != null) {
            contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use { it.write(pendingExport ?: "") }
            status.text = "Đã xuất danh sách TXT. Hãy giữ file riêng tư."
        }
    }
    private fun clearAccounts() {
        prefs.edit().remove("items").apply(); status.text = "Đã xóa danh sách lưu cục bộ."
    }
    private fun toggleTimer() {
        if (startedAt == 0L) startedAt = System.currentTimeMillis() else {
            elapsed += System.currentTimeMillis() - startedAt; startedAt = 0
        }
        updateTimer()
    }
    private fun updateTimer() {
        val total = (elapsed + if (startedAt != 0L) System.currentTimeMillis() - startedAt else 0L) / 1000
        timerText.text = "Thời gian: %02d:%02d".format(total / 60, total % 60)
    }
    override fun onResume() { super.onResume(); if (::timerText.isInitialized) handler.post(timerTick) }
    override fun onPause() { super.onPause(); handler.removeCallbacks(timerTick) }
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val timerTick = object : Runnable { override fun run() { updateTimer(); handler.postDelayed(this, 1000) } }
    override fun onBackPressed() { if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed() }
}
