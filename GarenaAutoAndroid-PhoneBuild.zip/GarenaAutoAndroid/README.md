# Garena Auto Android (project source)

Android helper app. It opens the official Garena sign-in page in a WebView and provides local utilities: generate a username/password suggestion, copy entered details, track elapsed time, manually save a record after the user confirms registration success, and export saved records as TXT.

## Build
- On a computer: open in Android Studio and build `assembleDebug`.
- On an Android phone: follow [BUILD-ON-PHONE-VI.md](BUILD-ON-PHONE-VI.md) to build in GitHub Actions without installing Android Studio.

## Important limitations
- This source project is not itself an APK; it must be built with Android Studio/Gradle or cloud CI.
- Registration, CAPTCHA, email/phone verification, and OTP entry remain manual in Garena's official page.
- It does not create disposable email addresses, poll OTP inboxes, submit registration forms, bypass verification, or automate repeated account creation.
- Saved credentials are stored locally in app preferences without encryption. Do not save passwords on a shared device; clear the list when finished.
- This is an unofficial helper and is not affiliated with Garena.
